
var myForm = function(data) {
	var form = document.createElement("form");
	var selectContener = document.createElement("div");
	var formtiltle = document.createElement("div");

			var selectContenerrow = document.createElement("div");
			var selectContenercol = document.createElement("div");
			var selectContenercol2 = document.createElement("div");
			var selectContenercol3 = document.createElement("div");
	// console.log(data.dataSets[0].dataEntryForm.id)
	// name of the form: use id
	form.id = data.dataSets[0].dataEntryForm.id;
	var formId = form.id;
	form.name = data.dataSets[0].dataEntryForm.name;
	// form.name = "malaria";

	var formLabel = document.createElement("label");getFormData
	formLabel.textContent = data.dataSets[0].name; // data set name
	selectContener.className = "container";
	selectContener.appendChild(formLabel)
	form.appendChild(selectContener);

			// next line
	var br = document.createElement("br");
	form.appendChild(br);

	// organisationUnits
	var orgLabel = document.createElement("label");
	orgLabel.textContent = "Select Organisation Unit: "
	orgLabel.className="oowncss"
	selectContenercol.appendChild(orgLabel);
	selectContenercol.className = "container";

	form.appendChild(selectContenercol);

	var selectOrgUnits = document.createElement("select");
	selectOrgUnits.name = "organisationUnit";
	// create org options
	data.dataSets[0].organisationUnits.map(function(organisationUnit) {
		var orgOption = document.createElement("option");
		orgOption.textContent = organisationUnit.name;
		orgOption.id = organisationUnit.id;
	 	selectOrgUnits.id = organisationUnit.id;

		selectOrgUnits.appendChild(orgOption);
	})
	selectContenercol.appendChild(selectOrgUnits);
	form.appendChild(selectContenercol);

	//period
	var period = document.createElement("select");
	period.name = "period";
	period.id = "period";
	var periodList = [201905, 201904, 201903, 201902, 201901, 201812, 201811];
	periodList.map(function(periodRange, index){
		var periodOption = document.createElement("option");
		periodOption.name = periodRange;
		periodOption.textContent = periodRange;
		period.appendChild(periodOption);
	})
	selectContenercol.appendChild(period);
	form.appendChild(selectContenercol);


	data.dataSets[0].dataSetElements.map(function(dataElement, index) {
			// console.log(dataElement.dataElement.categoryCombo.id)
			//console.log(dataElement)
			var element = document.createElement("div");
			var row = document.createElement("div");
			var col = document.createElement("div");
			var col2 = document.createElement("div");
			var col3 = document.createElement("div");

			



			var p = document.createElement("span");

			p.textContent = dataElement.dataElement.name + ":";
			//p.setAttribute("on")
			row.className= "row";
			col.className = "col-sm-2 list-group-item";
			col2.className = "col-sm-5 list-group-item";
			col3.className = "col-sm-5 list-group-item";



			p.id = dataElement.dataElement.id;
			p.className="";
			element.className = "container";
			col.appendChild(p);
			row.appendChild(col);
			element.appendChild(row);
			form.appendChild(element);
			// categoryOptions
			if(dataElement.dataElement.categoryCombo.id === "FVbhoWBHwrG") {
				dataElement.dataElement.categoryCombo.categoryOptionCombos.map(function(categoryOption, indx) {
					var input = document.createElement("input");
					// console.log(categoryOption);
					// console.log(categoryOption.name);
					input.type = "number";
					input.name = categoryOption.name;
					input.id = dataElement.dataElement.id + "." + categoryOption.id;
					col2.appendChild(input);
					row.appendChild(col2);
					element.appendChild(row);				});
			} else if(dataElement.dataElement.categoryCombo.id === "SRutekGT1bH") {
				data.dataSets[0].dataSetElements[0].dataElement.categoryCombo.categoryOptionCombos.map(function(categoryOption, pos) {
					var input = document.createElement("input");
					// console.log(categoryOption);
					// console.log(categoryOption.name);
					input.type = "number";
					input.name = categoryOption.name;
					input.id = dataElement.dataElement.id + "." + categoryOption.id;
					col3.appendChild(input);
					row.appendChild(col3);
					element.appendChild(row);
				});
			} else {

			}

		}
	);

			// form submit button
	var submitButton = document.createElement("input");
	submitButton.id = "submit_form";
	submitButton.type = "button";
	submitButton.value = "Submit";
	submitButton.name = "submit";
	submitButton.placeholder = "Submit";
	submitButton.setAttribute("onclick", 'getFormData()')
	form.appendChild(submitButton);

	
	var formPanel = document.getElementById('myForm1');
	formPanel.appendChild(form);
}	

var url= "http://localhost:8080/dhis/api/dataSets.json?fields=id,name,dataEntryForm[id,name],organisationUnits[id,name],dataSetElements[dataElement[id,name,categoryCombo[id,name,categoryOptionCombos[id,name]]]";

var response = function() {
	return fetch(url)
			.then(function(res) {
				// console.log(res)
				if (res.status === 200) {
					return res.json()
				}
			})
			.then(function(myDataSet){
				// console.log(myDataSet);
				myForm(myDataSet)
			});
}

response()



function getFormData(){

	var inputs = document.querySelector("form");
    var div = document.querySelector("div, id");

    var payload = {
    	"dataSet": "A9sqGZIEUtr", 
	    "period": [],
	    "orgUnit": [],
	    "dataValues":[]
    }

  	for (var i =0; i< inputs.length; i++) {
        // console.log(inputs[i].value);
        //console.log(inputs[i].type);
        var x = inputs[i].id;
        var xsplit = x.split(".");

        if (inputs[i].type==="number"){

        	payload.dataValues.push({
	        	"dataElement": xsplit[0],
	        	"categoryOptionCombo": xsplit[1], 
	        	"value":inputs[i].value
	        });

        } else if(inputs[i].type === "button"){
 
        } else {

        	if (document.querySelector("select").name === "organisationUnit"){

	        	payload.orgUnit.push({
		        	"name":inputs[i].value,
		        	"id":inputs[i].id
		        });
	        } 

	        if(document.getElementById("period").name === "period") {
    			payload.period.push({
		        	"value":inputs[i].value
		        });
        	}
        }
       
       // console.log(inputs)
	}
	Object.assign(payload, { "orgUnit":payload.orgUnit[0], "period": payload.period[1] });
    console.log(payload)



  var headers = new Headers();
             headers.append('Content-Type','application/json')

             fetch('http://localhost:8080/dhis/api/dataValueSets', {
                 method: 'POST',
                 headers : headers,
               body:JSON.stringify(
                    payload
                )}).then((res) => res.json())
               .then((data) =>  {console.log(data);
              });
}


