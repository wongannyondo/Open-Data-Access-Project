


var api= "http://localhost:8080/dhis/api/dataSets.json?fields=id,name,organisationUnits[id,name],dataSetElements[dataElement[id,name,categoryCombo[id,name,categoryOptionCombos[id,name]]]";

var url="http://localhost:8080/dhis/api/dataSets.json?fields=id,name,dataSetElements[dataElement[id,name,categoryCombo[id,name,categoryOptionCombos[id,name]]],organisationUnit[id,name]";

